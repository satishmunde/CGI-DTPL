from jinja2 import Environment, FileSystemLoader

# Create a Jinja2 environment with the templates directory
env = Environment(loader=FileSystemLoader('templates'))

# Load the template
template = env.get_template('template.html')


# Provide data to fill in the placeholders
data = {'title': 'My Page', 'content': 'Hello, Jinja2!'}

# Render the template with the data
output = template.render(data)

# Print or use the rendered output as needed
print(output)

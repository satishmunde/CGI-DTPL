let table;

const submitData = () => {
   
        console.log("Fetch Data...");
        let cname = document.getElementById('cname').value;
        let edate = document.getElementById('edate').value;
        let loc = document.getElementById('loc').value;
        let itemName = document.getElementById('item').value;
        let quantity = document.getElementById('quantity').value;
        let uom1 = document.getElementById('uom');
        let selectedUom = uom1.options[uom1.selectedIndex].value


        let challan = document.getElementById('challan').value;
        let remark = document.getElementById('remark').value;

        // Define the data to send to the CGI script
        var data = {
           cname,
           edate,
           
           item: itemName,
           qty: quantity,
           uom: selectedUom,
           loc,
           challan,
           remarks: remark

        };
        
        var jsonData = JSON.stringify(data);
        // console.log(jsonData);
        var url = "CGI_Files/get_data.py";

        var xhr = new XMLHttpRequest();

        xhr.open("POST", url, true);

        xhr.setRequestHeader("Content-Type", "application/json");

        xhr.onreadystatechange = function() {
            console.log(xhr.readyState);
            console.log(xhr.status);
            if (xhr.readyState === 4 && xhr.status === 200) {
                let indata = JSON.parse(this.responseText);
                let table = $('#myTable').DataTable();
    
                // Clear existing rows
                table.clear().draw();
                console.log(indata);
                // table.clear().draw();
    
                // Add updated data to the table
                table.rows.add(indata).draw();

                     
            }
        };

    // Send the JSON data to the CGI script
    xhr.send(jsonData);

    }



const inputField = document.getElementById('cname');
const suggestionsDiv = document.getElementById('suggestions');

let xhr = new XMLHttpRequest();


function getSuggestions() {
  let userInput = inputField.value;


  // Clear previous suggestions
//   suggestionsDiv.innerHTML = '';

  // Make a request to your CGI script passing user input as a parameter
  xhr.open('POST', 'CGI_Files/getcame.py', true);
  xhr.onreadystatechange = function () {
    // console.log(xhr.readyState);
    // console.log(xhr.status);
    if (this.readyState === 4 && this.status === 200){
        var response = this.responseText
          if(response == ""){
            suggestionsDiv.style.display = 'none';

         }
         else{
            const data = JSON.parse(response);
            console.log(data);
            displaySuggestions(data);
         }

        
       
      }
       
    };
  
  xhr.send(userInput);
}

function displaySuggestions(suggestions) {
    suggestionsDiv.innerHTML = '';

    suggestions.forEach(suggestion => {
      var suggestionElement = document.createElement('div');
      suggestionElement.classList.add('sug-div')
      suggestionElement.textContent = suggestion;
      suggestionElement.addEventListener('click', function() {
        inputField.value = suggestion;
        suggestionsDiv.style.display = 'none';
      });
      suggestionElement.addEventListener('focus', function() {
        
        suggestionsDiv.style.display = 'none';
      });
      suggestionsDiv.appendChild(suggestionElement);
    });
  
    if (suggestions.length > 0) {
      suggestionsDiv.style.display = 'block';
    } else {
      suggestionsDiv.style.display = 'none';
    }
}

const itemfiled = document.getElementById('item');
const itemsuggestionsDiv = document.getElementById('itemsuggestions');
function itemlist() {
    let itemdata = itemfiled.value;


  
  
    // Clear previous suggestions
    // itemsuggestionsDiv.innerHTML = '';
  
    // Make a request to your CGI script passing user input as a parameter
    xhr.open('POST', 'CGI_Files/getitem.py', true);
    xhr.onreadystatechange = function () {
      // console.log(xhr.readyState);
      // console.log(xhr.status);
      if (this.readyState === 4 && this.status === 200){
        var response = this.responseText
        if(response == ""){
            itemsuggestionsDiv.style.display = 'none';

       }
       else{
        itemsuggestionsDiv.style.display = 'block';

          const data = JSON.parse(response);
          console.log(data);
          itemdisplaySuggestions(data);
       }
        }
         
      };
    
    xhr.send(itemdata);
  }


function itemdisplaySuggestions(suggestions) {
    itemsuggestionsDiv.innerHTML = '';

    suggestions.forEach(suggestion => {
      var suggestionElement = document.createElement('div');
      suggestionElement.classList.add('sug-div')
      suggestionElement.textContent = suggestion;
      suggestionElement.addEventListener('click', function() {
        itemfiled.value = suggestion;
        itemsuggestionsDiv.style.display = 'none';
      });
      itemsuggestionsDiv.appendChild(suggestionElement);
    });
  
    if (suggestions.length > 0) {
      itemsuggestionsDiv.style.display = 'block';
    } else {
      itemsuggestionsDiv.style.display = 'none';
    }
}

   
    




function loadData() {
    let api = new XMLHttpRequest();
    console.log("Data is Loading...");

    api.open("GET", "CGI_Files/load_data.py", true);

    api.onload = function() {
        if (api.status >= 200 && api.status < 400) {
            var data = JSON.parse(this.responseText);
            console.log(data);

            $('#myTable').DataTable({
                order: [[0, 'desc']],
                data: data,
                columns: [
                    { data: 'id' },
                    { data: 'cname' },
                    { data: 'timestamp' },
                    { data: 'item' },
                    { data: 'qty' },
                    { data: 'uom' },
                    { data: 'challan' },
                    { data: 'remark' }
                ],
                initComplete: function () {
                    this.api().columns().every(function () {
                        let column = this;
                        let title = column.footer().textContent.trim();

                        // Create input element
                        let input = document.createElement('input');
                        input.classList.add('form-control')
                        
                        input.placeholder = title;
                        
                        if (title == 'Date'){
                            input.setAttribute('type', 'date');
                            console.log('Catch the element');
                        }
                        column.footer().replaceChildren(input);

                        // Event listener for user input
                        input.addEventListener('keyup', () => {
                            if (column.search() !== input.value) {
                                column.search(input.value).draw();
                                console.log(column.search(input.value).draw());
                            }
                        });
                    });
                }
            });
            
        } else {
            console.error('Failed to load data');
        }
    };

    api.onerror = function() {
        console.error('Error occurred while fetching data');
    };

    api.send();

}

loadData();







// function loadData()
    
//         {
//             let api =  new XMLHttpRequest();
//             console.log("Data is Loading...");

//             api.open("GET", "CGI_Files/load_data.py", true);
//             // api.getAllResponseHeaders('content-type','application/x-wwwpform-urlencoded')

//             api.onprogress = function (){
//                 console.log("On Progress");

//             }

//             api.onload = function ()

//             {
                
//                 var data =JSON.parse(this.responseText);
//                 // for (let index = inward_data.length-1; index >=0;  index--) {
//                 //     const element = inward_data[index];
  
                
//                   $('#myTable').DataTable({
//                     order: [[0, 'desc']],
                    
       
       


//                     // rowCallback: function(row) {
//                     //     // Example condition based on 'Age' property
//                     //          $(row).addClass('highlight-row'); // Add a CSS class to rows where Age > 60
                 
//                     //  },
//                     data: data, // Provide the fetched data here
//                     columns: [
                     
//                             {data:'id'},
//                             {data:'cname'},
//                             {data:'timestamp'},
//                             // {data:'loc'},
//                             {data:'item'},
//                             {data:'qty'},
//                             {data:'uom'},
//                             {data:'challan'},
//                             {data:'remark'}
//                         ],
//                         initComplete: function () {
//                             this.api()
//                                 .columns()
//                                 .every(function () {
//                                     let column = this;
//                                     let title = column.footer().textContent;
                     
//                                     // Create input element
//                                     let input = document.createElement('input');
//                                     input.placeholder = title;
//                                     column.footer().replaceChildren(input);
                     
//                                     // Event listener for user input
//                                     input.addEventListener('keyup', () => {
//                                         if (column.search() !== this.value) {
//                                             column.search(input.value).draw();
//                                         }
//                                     });
//                                 });
//                         }
//           });

                        
//                         // console.log(${'data':'id'});
            
                
                 
//                 // const table_data = `
//                 //     <tr>
//                 //         <th scope="row">${inward_data.id}</th>
//                 //         <td>${inward_data['cname']}</td>
//                 //         <td>${inward_data.timestamp}</td>
//                 //         <td>${inward_data.loc}</td>
//                 //         <td>${inward_data.item}</td>
//                 //         <td>${inward_data.qty}</td>
//                 //         <td>${inward_data.uom}</td>
//                 //         <td>${inward_data.challan}</td>
//                 //         <td>${inward_data.remark}</td>
//                 //     </tr>`;
                        
                    
//                 //     let tabletemp = document.getElementById('table-info').insertAdjacentHTML('afterbegin',table_data);
                
                
                      
                   
                
                
//             }
//             api.send();
//         }

    
// loadData();

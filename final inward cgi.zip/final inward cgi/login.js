const loginFun = () => {


        var xhr = new XMLHttpRequest();
        let uname = document.getElementById('uname').value;
        let pwd = document.getElementById('pwd').value;

        // Define the data to send to the CGI script
        var data = {
           uname,
           pwd
        };
        
        // Convert the data to a JSON string
        var jsonData = JSON.stringify(data);
    
        // var jsonData = "Data Send"
        
        // Define the URL of your Python CGI script
        var url = "CGI_Files/login.py"; // Update the URL as needed

      // Create an object to store the data you want to send

    

        // Open a POST request to the CGI script
        xhr.open("POST", url, true);
        

        // Set the request headers
        xhr.setRequestHeader("Content-Type", "application/json");

        // Define a callback function to handle the response
        xhr.onreadystatechange = function() {
            console.log(xhr.readyState);
            console.log(xhr.status);
           
            if (xhr.readyState === 4 && xhr.status === 200) {
                let indata =JSON.parse(this.responseText);
                if( indata['stat'] == 'sucess' ){
                        window.location.href = '/form.html';


                }
                else{
                

                        const alertbox = `<div class="alert ${indata['stat']}">
                                                <span class="closebtn">&times;</span>  
                                                <i class="fa-solid fa-badge-check fa-xl" style="color: #1dc95f;"></i> ${indata['message']}
                                                </div>
                                                `;
                        

                        let sectionid =document.getElementById('login')
                        sectionid.insertAdjacentHTML('afterbegin',alertbox);
                        var close = document.getElementsByClassName("closebtn");
                        var i;

                        for (i = 0; i < close.length; i++) {
                        close[i].onclick = function(){
                        var div = this.parentElement;
                        div.style.opacity = "0";
                        setTimeout(function(){ div.style.display = "none"; }, 600);}
  }
}

                

                     
            }
        }
    // Send the JSON data to the CGI script
    xhr.send(jsonData);

   
};



    
    
//         // Configure the request
//         xhr.open("GET", "/CGI_Files/login.py", true);
        
//         // Set up a callback function to handle the response
//         xhr.onreadystatechange = function()
//         {
//                 console.log(xhr.readyState);
//                 console.log(xhr.status);
//             if (xhr.readyState === 4 && xhr.status === 200)
//                 {
//                         // The request was successful, and the response is in xhr.responseText
//                         var response = JSON.parse(xhr.responseText);
//                         // if response.status == "error"
//                         // {
//                         //         alert(response.message);
//                         // }

//                         // console.log(response);
//                         // if(uname == duname && pwd == dpwd)
//                         // {
//                         // window.location.href = '/form.html';
//                         // }
//                         // else{
//                         // alert("Username or Password is incorrect")
//                         // }
//                 }
//         };
        
//         // Send the request
//         xhr.send();

// }
// callCGIScript();
// function callCGIScript() {
//     // Create an XMLHttpRequest object
//     console.log("cgi Script called");
//     var xhr = new XMLHttpRequest();
    
    
//     // Configure the request
//     xhr.open("GET", "/CGI_Files/form_cgi.py", true);
    
//     // Set up a callback function to handle the response
//     xhr.onreadystatechange = function() {
//         if (xhr.readyState === 4 && xhr.status === 200) {
//             // The request was successful, and the response is in xhr.responseText
//             var response = xhr.responseText;
//             console.log("Response from CGI script: " + response);
//         }
//     };
    
//     // Send the request
//     xhr.send();
// }

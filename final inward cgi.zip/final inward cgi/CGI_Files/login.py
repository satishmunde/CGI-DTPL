#!/usr/bin/env python

import json
import pymysql
import sys
import cgi,cgitb

# Get the incoming JSON data from standard input
json_data = sys.stdin.read()
# Get the incoming JSON data
# form = cgi.FieldStorage(environ={'REQUEST_METHOD': 'POST'})
data = json.loads(json_data)
# response = {
#         "stat": "error",
#             "message": "Please Enter ID and PASSWORD",
#             'data':data['uname']
#         }
uname = data['uname']
pwd = data['pwd']
if len(uname)==0 and len(pwd)==0:
    response = {
        "stat": "error",
            "message": "Please Enter ID and PASSWORD"
        }
elif len(uname) == 0:
    response = {
            "stat": "error",
            "message": "Please Enter Username"
        }
        
elif len(pwd) == 0:
    response = {
            "stat": "error",
            "message": "Please Enter The Password"
        }
        
            

else:
    try:
        conn = pymysql.connect(host="localhost",user="root", password="",database='INWARD')
        cr = conn.cursor()
                # print(f"SELECT PASSWORD FROM emplogin WHERE USERNAME = {uname}")
        query = 'SELECT password,username FROM emplogin WHERE username =\''+uname+"\'"
        try: 
            cr.execute(query)
            conf = cr.fetchone()[0]
                
                
            if conf != pwd:
                response = {
                        "stat": "error",
                        "message": "Invalid Password"
                    }
                        
            else:
                response = {
                        "stat": "sucess",
                        "message": "Logged In"
                    }
                
                        
                        
        except Exception as e:
            response = {
                        "stat": "error",
                        "message": "Invalid Username"
                    }
                    
                    
                    
    except Exception as e:
        response = {
                        "stat": "error",
                        "message": str(e)
                    }
    
   

    finally:
        conn.close()
  

# Set the content type to JSON
print("Content-Type: application/json")
print()  # End the header with a blank line

# Output the JSON data
print(json.dumps(response))



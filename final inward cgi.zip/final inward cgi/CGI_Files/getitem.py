#!/usr/bin/env python
import cgi
import json
import pymysql

import sys  


json_data = sys.stdin.read()
if json_data:

    try:
    
        # itemdata = json.loads(json_data)
        # Database connection
        conn = pymysql.connect(
                host="localhost",
                user="root",
                password="",
                database="INWARD"
            )
        
  
        datalist = []
        cursor = conn.cursor()


        query = f"SELECT DISTINCT ITEM_NAME FROM Data WHERE ITEM_NAME LIKE '%{json_data}%'"
        cursor.execute(query)
        data = cursor.fetchall()
        if data:
            for item in data:
                for name in item:
                    datalist.append(str(name))

        conn.close()


    except Exception as e:
        datalist = []
        datalist.append(str(e))

print("Content-Type: application/json")
print()  # End the header with a blank line
print(json.dumps(data))
#!/usr/bin/env python

import cgi
import json
import pymysql

import sys
import logging



try:

    # Database connection
    conn = pymysql.connect(
            host="localhost",
            user="root",
            password="",
            database="INWARD"
        )
    
    datalist = []
    cursor = conn.cursor()


    query = "SELECT * FROM Data"
    cursor.execute(query)
    data = cursor.fetchall()
    if data:
        for item in data:
            itemdate = str(item[2])
            response = {
                'id': item[0],
                'cname': item[1],
                'timestamp': itemdate[0:11], 
                # 'loc': item[6],
                'item': item[3],
                'qty': item[4],
                'uom': item[5],
                'challan': item[7],
                'remark': item[8],
                
            }
            datalist.append(response)

        conn.close()
        print("Content-Type: application/json")
        print()  # End the header with a blank line

        # Output the JSON data
        print(json.dumps(datalist))
    else:
        response = {'status': 'No data found'}

    # print("Content-Type: application/json")
    # print()
    # print(json.dumps(response))

    conn.close()

 

except Exception as e:
    conn.close()
    response = {
            "status": "error",
            "message": data
        }

  
# print("Content-Type: application/json")
# print()  # End the header with a blank line

# # Output the JSON data
# print(json.dumps(response))



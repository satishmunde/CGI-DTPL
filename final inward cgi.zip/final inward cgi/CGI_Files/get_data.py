#!/usr/bin/python3

import cgi
import json
import pymysql

import sys  

# Get the incoming JSON data from standard input
json_data = sys.stdin.read()
# Get the incoming JSON data
form = cgi.FieldStorage(environ={'REQUEST_METHOD': 'POST'})

response = {
            "status": "failed",
            "message": "Data Not Receive",
            
        }


if json_data:
    
    try:
        data = json.loads(json_data)
        

        conn = pymysql.connect(
            host="localhost",
            user="root",
            password="",
            database="INWARD"
        )
    
   
        cursor = conn.cursor()
        values = [data['cname'],data['edate'],data['item'],data['qty'],data['uom'],data['loc'],data['challan'],data['remarks']]
  
        response = []
        query = "INSERT INTO Data (COMPANY_NAME,ENTRY_DATE,ITEM_NAME,QUANTITY,UOM,LOC,CHALAN_NO,REMARK) values(%s,%s,%s,%s,%s,%s,%s,%s)"
        cursor.execute(query,values)
        conn.commit()
        query = "SELECT * FROM Data"
        cursor.execute(query)
        data = cursor.fetchall()
        if data:
            for item in data:
                itemdate = str(item[2])
                datalist = {
                    'id': item[0],
                    'cname': item[1],
                    'timestamp': itemdate[0:11], 
                    # 'loc': item[6],
                    'item': item[3],
                    'qty': item[4],
                    'uom': item[5],
                    'challan': item[7],
                    'remark': item[8],
                    
                }
                response.append(datalist)

       
        
        conn.close()
    except Exception as e:
        response = {
            "status": "error",
            "message": str(e),
          
        }

print("Content-Type: application/json")
print()  
print(json.dumps(response))

#!/usr/bin/env python
import cgi
import json
import pymysql

import sys  


json_data = sys.stdin.read()
if json_data:

    try:
    

        # Database connection
        conn = pymysql.connect(
                host="localhost",
                user="root",
                password="",
                database="INWARD"
            )
        
  
        datalist = []
        cursor = conn.cursor()


        query = f"SELECT DISTINCT COMPANY_NAME FROM Data WHERE COMPANY_NAME LIKE '%{json_data}%'"
        cursor.execute(query)
        data = cursor.fetchall()
        if data:
            for item in data:
                for name in item:
                    datalist.append(str(name))

        conn.close()


    except Exception as e:
        datalist = []
        datalist.append(e)

print("Content-Type: application/json")
print()  # End the header with a blank line
print(json.dumps(datalist))